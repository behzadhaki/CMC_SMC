from torch.utils.data import Dataset
import glob, os
import pickle
import torch

import pandas as pd
pd.options.mode.chained_assignment = None  # default='warn'

note_to_index_dict = {
        "hold": 0,
        "rest": 1,
        "A": 2,
        "A#": 3,
        "Bb": 3,
        "B": 4,
        "Cb": 4,
        "B#": 5,
        "C": 5,
        "C#": 6,
        "Db": 6,
        "D": 7,
        "D#": 8,
        "Eb": 8,
        "E": 9,
        "Fb": 9,
        "E#": 10,
        "F": 10,
        "F#": 11,
        "Gb": 11,
        "G": 12,
        "G#": 13,
        "Ab": 13 }


class MelodyDataset(Dataset):

    # __getitem__ () returns the input (one-hot) and output (categorical)
    # In this tutorial we will only use input!
    def __init__(self, csv_directory, note_to_index_dict,
                 measure_duration=16, n_measures_per_segment=1,
                 hop_size_in_measure=1, transform=None):

        # Find all csv files in csv_folder
        csv_files = glob.glob(csv_directory)

        # list to hold dataset
        self.dataset = []

        # Figure out the number of classes in the note_to_index_dict
        classes = []
        for key in note_to_index_dict.keys():
            classes.append(note_to_index_dict[key])
        n_classes_in_dataset =len(set(classes))

        # pickle path for the processed dataset (We don't want to process dataset everytime we run the training)
        pickle_path = os.path.join(*csv_directory.split("/")[:-1])
        pickle_path = os.path.join(
            pickle_path,
            "processed_data_{}_measures_per_segment_with_measure_duration_{}_hopSize_{}.p".format(
                n_measures_per_segment,
                measure_duration,
                hop_size_in_measure
            )
        )

        if not os.path.isfile(pickle_path):    # process if already not processed, otherwise load pickled processed data

            print("*"*20, " Processing data")
            # load all csvs and break into segments
            self.targets, self.segments, self.file_names, self.measure_start_positions = self.process_to_list(
                csv_directory,
                note_to_index_dict,
                n_measures_per_segment,
                measure_duration,
                hop_size_in_measure
            )

            self.targets = torch.tensor(self.targets)

            self.inputs = torch.nn.functional.one_hot(
                self.targets.to(torch.int64),
                n_classes_in_dataset)

            self.inputs = self.inputs.flatten(1)
            self.inputs = self.inputs.type(torch.float32)

            dict_to_pickle = {
                "targets": self.targets,
                "inputs": self.inputs,
                "segments": self.segments,
                "file_names": self.file_names,
                "measure_start_positions": self.measure_start_positions
            }

            pickle.dump(dict_to_pickle, open(pickle_path,"wb"))

            print("*"*20, "\n Processed data pickled at", pickle_path)

        else:
            print("*" * 20, "\n Data already processed and pickled. Loading from ", pickle_path)

            dict_from_pickle = pickle.load(open(pickle_path, "rb"))

            self.targets = dict_from_pickle["targets"]
            self.inputs = dict_from_pickle["inputs"]
            self.segments = dict_from_pickle["segments"]
            self.file_names = dict_from_pickle["file_names"]
            self.measure_start_positions = dict_from_pickle["measure_start_positions"]

    def __len__(self):                         # THIS IS NECESSARY FOR EVERY DATASET INSTANCE
        return len(self.targets)

    def __getitem__(self, item):               # THIS IS NECESSARY FOR EVERY DATASET INSTANCE
        # returns input and target
        return self.inputs[item], self.targets[item]

    def process_to_list(self,
                        csv_directory,
                        note_val_dict,
                        n_measures_per_segment=4,
                        measure_duration=16,
                        hop_size_in_measure=1):

        sequences = []
        segments = []
        file_names = []
        measure_start_positions = []

        for csv_file in glob.glob(csv_directory):
            df = pd.read_csv(csv_file)
            if df["time"][0] == "4/4":
                df["cumsum"] = df.note_duration.cumsum()
                n_measures = max(df["measure"])

                if type(n_measures) == int:
                    for measure_start in range(n_measures - n_measures_per_segment):
                        if (measure_start % hop_size_in_measure) == 0:
                            measure_start = measure_start + 1
                            file_names.append(csv_file)
                            measure_start_positions.append(measure_start)
                            sequence = [0] * (measure_duration * n_measures_per_segment)
                            segment = df[(measure_start <= df["measure"]) & (
                                        df["measure"] < (measure_start + n_measures_per_segment))]

                            segment["cumsum"] = segment.note_duration.cumsum()
                            segment.index = range(len(segment.index))
                            segments.append(segment)

                            for ix, note in enumerate(segment["note_root"]):

                                note = note.replace("0", "")
                                note = note.replace("-2", "")
                                note = note.replace("2", "")

                                if ix == 0:
                                    sequence[0] = note_val_dict[note]
                                else:
                                    if int(segment["cumsum"][ix - 1]) < measure_duration * n_measures_per_segment:
                                        sequence[int(segment["cumsum"][ix - 1])] = note_val_dict[note]

                            sequences.append(sequence)

        return sequences, segments, file_names, measure_start_positions

